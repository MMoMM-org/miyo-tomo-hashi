#!/usr/bin/env bash
#
# reset-vault.sh — Restore the test/Hashi vault to its pristine state.
#
# Wipes the vault content (NOT .obsidian/, NOT the .zip files, NOT this script)
# and re-extracts Archive.zip. macOS resource-fork junk is filtered out.
#
# Operates ONLY on the directory containing this script — never anywhere else.
# Multiple sanity checks fail-fast if anything looks wrong before any rm runs.
#
# Usage:
#   bash test/Hashi/reset-vault.sh
#
# After running:
#   1. The vault is back to the snapshot in Archive.zip.
#   2. .obsidian/ config + plugins are preserved.
#   3. Re-deploy the plugin if you've rebuilt:
#        HASHI_DEPLOY_VAULT=1 npm run build

set -euo pipefail

# ---------------------------------------------------------------------------
# Resolve paths to canonical absolute form. Refuses to run on symlinks that
# might point outside the expected directory.
# ---------------------------------------------------------------------------
SCRIPT_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
VAULT_DIR="$SCRIPT_PATH"

# ---------------------------------------------------------------------------
# Sanity gauntlet — every check must pass before any rm runs.
# ---------------------------------------------------------------------------

fail() {
	echo "✗ refuse: $*" >&2
	echo "  script location: $VAULT_DIR" >&2
	exit 1
}

# 1. Refuse common dangerous parents (defense-in-depth — should never trigger).
case "$VAULT_DIR" in
	"" | "/" | "$HOME" | "/Users" | "/Volumes" | "/tmp" | "/private/tmp" | "/etc" | "/usr"*)
		fail "vault dir resolves to a system or home path"
		;;
esac

# 2. Refuse if the script is not in a directory literally named "Hashi" with
#    a parent literally named "test". This pins the script to its checked-in
#    location even if someone copies it elsewhere.
PARENT_DIR="$(basename "$(dirname "$VAULT_DIR")")"
LEAF_DIR="$(basename "$VAULT_DIR")"
if [[ "$LEAF_DIR" != "Hashi" ]]; then
	fail "leaf directory must be named 'Hashi' (got: $LEAF_DIR)"
fi
if [[ "$PARENT_DIR" != "test" ]]; then
	fail "parent directory must be named 'test' (got: $PARENT_DIR)"
fi

# 3. Refuse if expected vault markers are missing — proves we're at the right
#    target and not in a fresh empty directory by accident.
[[ -d "$VAULT_DIR/.obsidian" ]] \
	|| fail ".obsidian/ not found — this does not look like the test vault"
[[ -f "$VAULT_DIR/Archive.zip" ]] \
	|| fail "Archive.zip not found — nothing to restore from"
[[ -f "$VAULT_DIR/reset-vault.sh" ]] \
	|| fail "reset-vault.sh not found at expected location"

# 4. Confirm we're inside the miyo-tomo-hashi repo by checking the git toplevel
#    matches and the expected repo files exist two levels up. This catches the
#    case where someone copied the test/Hashi tree out of the repo.
REPO_ROOT="$(cd "$VAULT_DIR/../.." && pwd -P)"
[[ -f "$REPO_ROOT/package.json" ]] && [[ -f "$REPO_ROOT/manifest.json" ]] \
	|| fail "$REPO_ROOT does not look like the miyo-tomo-hashi repo root"

# All checks passed — proceed.
echo "→ Resetting vault at $VAULT_DIR"
echo "  (verified: leaf=Hashi, parent=test, .obsidian/ + Archive.zip present)"

# ---------------------------------------------------------------------------
# Wipe everything except .obsidian/, *.zip, this script, SETUP.md.
# Confined strictly to $VAULT_DIR via -mindepth 1 -maxdepth 1; never recurses
# upward. The find expression skips preserved entries before any rm.
# ---------------------------------------------------------------------------
find "$VAULT_DIR" -mindepth 1 -maxdepth 1 \
	! -name ".obsidian" \
	! -name ".tomo-hashi" \
	! -name "*.zip" \
	! -name "reset-vault.sh" \
	! -name "SETUP.md" \
	-print -exec rm -rf {} +

# ---------------------------------------------------------------------------
# Re-extract Archive.zip; targets only $VAULT_DIR. Excludes macOS junk.
# Prefers `unzip`; falls back to python3's zipfile when unzip is absent
# (e.g. the Linux dev container ships no unzip).
# ---------------------------------------------------------------------------
echo "→ Extracting Archive.zip"
if command -v unzip >/dev/null 2>&1; then
	unzip -q -o "$VAULT_DIR/Archive.zip" -d "$VAULT_DIR" \
		-x "__MACOSX/*" "*/.DS_Store"
elif command -v python3 >/dev/null 2>&1; then
	echo "  (unzip not found — using python3 zipfile)"
	VAULT_DIR="$VAULT_DIR" python3 - <<'PY'
import os, zipfile
vault = os.environ["VAULT_DIR"]
with zipfile.ZipFile(os.path.join(vault, "Archive.zip")) as z:
	members = [m for m in z.namelist()
	           if not m.startswith("__MACOSX/") and not m.endswith(".DS_Store")]
	z.extractall(vault, members=members)
print(f"  extracted {len(members)} members")
PY
else
	fail "neither unzip nor python3 available to extract Archive.zip"
fi

# Belt-and-braces: scrub any __MACOSX or .DS_Store that slipped through —
# search confined to $VAULT_DIR via the explicit path argument.
find "$VAULT_DIR" -name "__MACOSX" -type d -prune -exec rm -rf {} + 2>/dev/null || true
find "$VAULT_DIR" -name ".DS_Store" -delete 2>/dev/null || true

echo ""
echo "✓ Vault reset complete."
echo ""
echo "Next steps:"
echo "  1. Build + deploy the plugin:"
echo "       HASHI_DEPLOY_VAULT=1 npm run build"
echo "  2. Open Obsidian → 'Open another vault' → select test/Hashi"
echo "  3. Enable the plugin under Settings → Community plugins"
echo "  4. Walk the checklist in SETUP.md"
