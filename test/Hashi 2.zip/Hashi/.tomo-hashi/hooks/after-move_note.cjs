// Post-move: rewrite alias to "<title> (HASHI)".
module.exports = async function (ctx) {
  const { action, app, logger } = ctx;
  const file = app.vault.getAbstractFileByPath(action.destination);
  if (!file) {
    return { warnings: [`File not found at ${action.destination}`] };
  }

  await app.fileManager.processFrontMatter(file, (fm) => {
    fm.aliases = [`${action.title} (HASHI)`];
  });

  logger.info(`alias → "${action.title} (HASHI)"`);
  return { info: [`alias → "${action.title} (HASHI)"`] };
};
