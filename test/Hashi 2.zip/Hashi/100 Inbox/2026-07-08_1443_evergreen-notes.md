---
tomo:
  doc_type: rendered-note
  state: pending-move
  run_id: 2026-07-08T14-43-30Z-7065d3
  updated_at: 2026-07-08T14:43:46Z
UUID: 20260708164416
DateStamp: 2026-07-08
Updated: 2026-07-08 16:44
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Evergreen Notes
tags:
  - type/note/normal
  - status/fleeting/🎗️
  - topic/knowledge/lyt
aliases:
  - 08.07.2026_1443_evergreen-notes
---

> [!connect] Your way around
> up:: [[Type of Notes (MOC)]]
> related:: 

# [[Evergreen Notes]]

``` dataviewjs
let page = dv.current();
if (page.summary && page.summary.length > 0) {
    dv.paragraph("\n**Summary:** _" + page.summary + "_");
}
```

# Evergreen Notes

Entry: https://notes.andymatuschak.org/z4SDCZQeRo4xFEQ8H4qrSqd68ucpgE6LU155C

Zettelkasten / Evergreen Notes: https://notes.andymatuschak.org/z4AX7pHAu5uUfmrq4K4zig9x8jmmF62XgaMXm

atomic notes etc. https://youtu.be/wB89lJs5A3s?t=10614

Seeds dienen als Basis, aus denen werden dann die Ferns extrahiert und dann weiter in Evergreen Notes umgewandelt.

Wen Seeds keinen weiteren Nutzen mehr bringen können werden sie in Grown umgewandelt.
