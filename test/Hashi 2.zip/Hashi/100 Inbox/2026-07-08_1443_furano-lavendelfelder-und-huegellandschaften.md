---
tomo:
  doc_type: rendered-note
  state: pending-move
  run_id: 2026-07-08T14-43-30Z-7065d3
  updated_at: 2026-07-08T14:43:46Z
UUID: 20260708164421
DateStamp: 2026-07-08
Updated: 2026-07-08 16:44
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Furano — Lavendelfelder und Hügellandschaften
tags:
  - type/note/normal
  - status/fleeting/🎗️
  - topic/japan
  - topic/geography
  - topic/recreation/vacation
aliases:
  - 2026-07-08_1443_Furano-Lavender Fields and Hilly Landscapes
---

> [!connect] Your way around
> up:: [[Japan (MOC)]]
> related:: 

# [[Furano — Lavendelfelder und Hügellandschaften]]

``` dataviewjs
let page = dv.current();
if (page.summary && page.summary.length > 0) {
    dv.paragraph("\n**Summary:** _" + page.summary + "_");
}
```

Furano liegt im Zentrum Hokkaidos und ist bekannt für die Lavendelfelder, die im Juli und August blühen. Farm Tomita ist der bekannteste Ort dafür.

Im Winter verwandelt sich Furano in ein Skigebiet mit Powder Snow, der weltweit als einer der besten gilt. Die Region produziert auch Wein, Käse und Melonen — eine ungewöhnliche Kombination für Japan.
