---
tomo:
  doc_type: rendered-note
  state: pending-move
  run_id: 2026-07-08T14-43-30Z-7065d3
  updated_at: 2026-07-08T14:43:52Z
UUID: 20260708164446
DateStamp: 2026-07-08
Updated: 2026-07-08 16:44
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Deliberate Practice — Focused Effort Beyond Automaticity
tags:
  - type/note/normal
  - status/fleeting/🎗️
  - growth/aol/development
  - growth/self
aliases:
  - 08.07.2026_1443_gezieltes-Training-mit-Fokus-auf-Anstrengung-über-die-Automatisierung-hinaus
---

> [!connect] Your way around
> up:: [[Concepts (MOC)]]
> related:: 

# [[Deliberate Practice — Focused Effort Beyond Automaticity]]

``` dataviewjs
let page = dv.current();
if (page.summary && page.summary.length > 0) {
    dv.paragraph("\n**Summary:** _" + page.summary + "_");
}
```

Deliberate practice, studied extensively by Anders Ericsson, is not mere repetition. It is focused, effortful practice aimed just beyond your current ability, with immediate feedback and constant correction of specific weaknesses. Ordinary practice plateaus once a skill becomes automatic; deliberate practice deliberately breaks that comfort, isolating sub-skills and drilling them. It is mentally taxing, which is why few people sustain it — and why it separates experts from the merely experienced.
