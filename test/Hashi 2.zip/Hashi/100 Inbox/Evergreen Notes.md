---
Updated: 2026-07-07 18:02
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:54Z
---

# Evergreen Notes

Entry: https://notes.andymatuschak.org/z4SDCZQeRo4xFEQ8H4qrSqd68ucpgE6LU155C

Zettelkasten / Evergreen Notes: https://notes.andymatuschak.org/z4AX7pHAu5uUfmrq4K4zig9x8jmmF62XgaMXm

atomic notes etc. https://youtu.be/wB89lJs5A3s?t=10614

Seeds dienen als Basis, aus denen werden dann die Ferns extrahiert und dann weiter in Evergreen Notes umgewandelt.

Wen Seeds keinen weiteren Nutzen mehr bringen können werden sie in Grown umgewandelt.