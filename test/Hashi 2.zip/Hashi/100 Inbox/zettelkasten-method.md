---
Updated: 2026-07-07 18:03
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:03:08Z
---
The Zettelkasten is a note-taking system developed by the sociologist Niklas Luhmann, who credited it with helping him publish more than 70 books. The core principle is the atomic note: one idea per note, written in your own words, each densely linked to related notes. Unlike a folder hierarchy, meaning does not come from where a note is filed but from the web of links between notes. Over years the Zettelkasten becomes a genuine thinking partner: you follow chains of linked notes and surface connections you never consciously planned. The three disciplines that make it work are writing self-contained notes, linking generously, and revisiting old notes so the network keeps growing.
