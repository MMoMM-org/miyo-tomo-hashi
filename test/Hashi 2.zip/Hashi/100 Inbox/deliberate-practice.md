---
Updated: 2026-07-07 18:03
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:03:02Z
---
Deliberate practice, studied extensively by Anders Ericsson, is not mere repetition. It is focused, effortful practice aimed just beyond your current ability, with immediate feedback and constant correction of specific weaknesses. Ordinary practice plateaus once a skill becomes automatic; deliberate practice deliberately breaks that comfort, isolating sub-skills and drilling them. It is mentally taxing, which is why few people sustain it — and why it separates experts from the merely experienced.
