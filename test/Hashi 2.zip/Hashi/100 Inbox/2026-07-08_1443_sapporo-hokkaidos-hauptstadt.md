---
tomo:
  doc_type: rendered-note
  state: pending-move
  run_id: 2026-07-08T14-43-30Z-7065d3
  updated_at: 2026-07-08T14:43:46Z
UUID: 20260708164436
DateStamp: 2026-07-08
Updated: 2026-07-08 16:44
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Sapporo — Hokkaidos Hauptstadt
tags:
  - type/note/normal
  - status/fleeting/🎗️
  - topic/japan
  - topic/japan/city
  - topic/geography
aliases:
  - 2026-07-08_1443_Sapporo the capital of Hokkaido
---

> [!connect] Your way around
> up:: 
> related:: 

# [[Sapporo — Hokkaidos Hauptstadt]]

``` dataviewjs
let page = dv.current();
if (page.summary && page.summary.length > 0) {
    dv.paragraph("\n**Summary:** _" + page.summary + "_");
}
```

Sapporo ist die Hauptstadt der Präfektur Hokkaido und mit knapp 2 Millionen Einwohnern die fünftgrößte Stadt Japans. Bekannt für das jährliche Schneefestival (Yuki Matsuri) im Februar, die Bierbrauerei-Tradition und als Austragungsort der Olympischen Winterspiele 1972.

Die Stadt bietet eine Mischung aus urbanem Leben und Naturzugang — der Odori Park teilt das Zentrum, und innerhalb von 30 Minuten erreicht man Skigebiete. Die Ramen-Szene (Miso-Ramen) ist legendär.
