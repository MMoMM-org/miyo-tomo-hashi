---
Updated: 2026-07-07 18:03
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:03:02Z
---
First principles thinking means breaking a problem down to its most
fundamental truths and reasoning up from there, instead of arguing by
analogy. Aristotle called it the first basis from which a thing is known.
Musk uses it in engineering: what do the laws of physics actually require?
It is slow and effortful, which is why most people reason by analogy —
but it is where genuinely novel solutions come from.
