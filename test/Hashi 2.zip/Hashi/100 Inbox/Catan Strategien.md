---
UUID: 20260417160001
DateStamp: 2026-04-17
Updated: 2026-07-07 18:02
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
tags:
  - "#type/note/zettel"
  - "#status/fleeting/💯"
obsidianUIMode: source
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:54Z
---

Die beste Eröffnungsstrategie bei Catan hängt von der Ressourcenverteilung ab. Erz+Weizen auf hohen Zahlen (6, 8) ermöglicht frühe Stadtentwicklung. Holz+Lehm auf 5, 9 sichert Straßenbau.

Longest Road ist weniger wertvoll als Largest Army — Ritter geben Flexibilität und der Räuber-Schutz ist ein Nebeneffekt. Handelshafen (3:1) sind unterschätzt wenn man eine Ressource dominiert.
