---
Updated: 2026-07-07 18:02
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:54Z
---
source: Apothekerpfädchen 11__2026-04-22 10:14:41.m4a
transcribed: 2026-05-26T15:18:28
recorded: 2026-04-22T10:14:41
model: faster-whisper-medium
language: de
duration_sec: 183
transcribe_sec: 44.38

---

![[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a]]

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=0|00:00]]
> Ich soll jetzt hier ein dreiminütiges W-File basteln oder M4 irgendwas.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=8|00:08]]
> Also überlegte ich mir gerade was ich da sagen soll, weil wir haben ja jetzt erst irgendwie

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=13|00:13]]
> 15 Sekunden durch.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=15|00:15]]
> Ehrlich gesagt ist das gar nicht so einfach.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=18|00:18]]
> Also ich bin momentan hier im Schlafzimmer, lege auf dem Bett und schaue mir die Wand

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=23|00:23]]
> an.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=24|00:24]]
> An der Wand hängen zwei von diesen japanischen Towels.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=27|00:27]]
> Einmal das mit den Yoga-Posen und dann mit diesem blauen Oni, den ich mal tauschen muss

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=35|00:35]]
> gegen das Feierdrahen.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=37|00:37]]
> An der Decke hängt eine Lampe, in der Ecke sitzt der Eulentürstopper.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=43|00:43]]
> Ansonsten draußen scheint die Sonne.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=47|00:47]]
> Ich habe gerade eben bei der Physiotherapie, habe da um 9.25 Uhr einen Termin gehabt

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=55|00:55]]
> und da haben wir uns die Schmerzen im oberen Beckenbereich mal angeschaut.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=61|01:01]]
> Und heute um 13.25 Uhr, oder nee um 14 Uhr, keine Ahnung, muss ich noch mal genau nachgucken,

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=70|01:10]]
> habe ich einen Termin beim Urologin.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=74|01:14]]
> Mal schauen was die sagt bezüglich der Schmerzen beim Stehen und auch was man

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=84|01:24]]
> sonst noch alles machen kann in dem Bereich Kinesialien.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=90|01:30]]
> Und jetzt haben wir schon eine Minute und 35 Sekunden durch.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=97|01:37]]
> Es ist also schwer so lange irgendwie blödsinnig rumzulabern.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=101|01:41]]
> Manche Leute können das ja nicht weniger.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=105|01:45]]
> Was noch?

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=106|01:46]]
> Heute Abend ist dann ordentlich spielen angesagt.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=109|01:49]]
> Ein bisschen ausprobieren, morgen früh wird weiter gemacht.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=115|01:55]]
> Tomo funktioniert ganz gut.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=119|01:59]]
> Das ist auch grundsätzlich dieses komische Voice-Script hier runterreden, weil wir

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=129|02:09]]
> das zum Testen brauchen.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=131|02:11]]
> Dann haben wir noch Cardo.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=134|02:14]]
> Cardo funktioniert super.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=135|02:15]]
> Ich muss dann mal schauen wie das alles läuft.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=139|02:19]]
> Das Problem bei Tomo ist sicherlich, dass es Cloud Code basierend ist.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=142|02:22]]
> Dann müssen wir mal gucken wie sich das weiterentwickelt.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=145|02:25]]
> Vor allem wie das auch ohne Maxplan laufen würde.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=149|02:29]]
> Ich höre von aus, dass ein normaler Max und 5er reichen sollte.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=153|02:33]]
> Das wären dann 100 Euro im Monat.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=156|02:36]]
> Mal gucken.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=157|02:37]]
> Pro reicht glaube ich nicht.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=158|02:38]]
> Da müsste man gucken, weil die Kontexte so groß sind.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=161|02:41]]
> Da müsste man vielleicht dann wiederum die Kontexte verkleinern, indem man da semantische

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=169|02:49]]
> Sachen einbaut und nicht die komplette Datei durchführt.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=172|02:52]]
> Gerade nachher mit dem Mox Squeeze Point Prozess, den wir noch implementieren müssen.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=177|02:57]]
> Damit sind die drei Minuten um.

> [!voice] [[Apothekerpfädchen 11__2026-04-22 10:14:41.m4a#t=180|03:00]]
> Jawoll.

