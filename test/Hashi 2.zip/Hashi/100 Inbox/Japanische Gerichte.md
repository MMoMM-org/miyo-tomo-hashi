---
UUID: 20221201161416
DateStamp: 2022-12-01
Updated: 2026-07-07 18:02
publish: false
language: de
Vault: Privat
VaultVersion: 1
title: Japanische Gerichte
aliases:
  - Japanische Rezepte
tags:
  - "#type/note/normal"
  - "#status/fleeting/🎗️"
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:56Z
---
> [!METADATA]-
> - Created:: [[2022-12-01]]
> - Related::
> - Summary::
> - Content:: [[Rezept]]
> - up:: 
> - Topics:: 
> - Type:: #type/note/normal
> - Status:: #status/fleeting/🎗️ 
> - **Reference**::
---

# [[Japanische Gerichte]]

## Zum Probieren

### Nudeln

https://www.japandigest.de/japan-in-deutschland/rezepte/spatzlepfanne-nach-yaki-udon-art/
https://www.japandigest.de/japan-in-deutschland/rezepte/yakisoba-mit-spiegelei/
https://www.justonecookbook.com/toshikoshi-soba/

### Komplettes Gericht
https://www.japandigest.de/japan-in-deutschland/rezepte/gyu-don/
https://www.japandigest.de/japan-in-deutschland/rezepte/bauernsuppe-mit-suesskartoffeln/
https://www.japandigest.de/japan-in-deutschland/rezepte/haehnchen-miso-sahne-gemuese/


### Sandwiches
https://www.japandigest.de/japan-in-deutschland/rezepte/patapata-onigirazu/
https://www.japandigest.de/japan-in-deutschland/rezepte/katsu-sando/
https://www.japandigest.de/japan-in-deutschland/rezepte/onigirazu-2/
https://www.japandigest.de/japan-in-deutschland/rezepte/onigirazu/


### Fleisch
https://www.japandigest.de/japan-in-deutschland/rezepte/haehnchenbrust-age-yaki/
https://www.japandigest.de/japan-in-deutschland/rezepte/rindersteak-mit-wasabi/
https://www.japandigest.de/japan-in-deutschland/rezepte/tonkatsu-miso-sauce/
https://www.japandigest.de/japan-in-deutschland/rezepte/buta-no-shogayaki-mit-kohl/


### Sushi

https://www.japandigest.de/japan-in-deutschland/rezepte/futo-maki/

### Beilagen
https://www.japandigest.de/japan-in-deutschland/rezepte/imo-mochi/ (Kartoffeln)
https://www.japandigest.de/japan-in-deutschland/rezepte/gemuese-kimpira/


## Für gut befunden

### Ramen
https://www.theflavorbender.com/easy-homemade-chicken-ramen/ (ohne Dashi)
https://www.theflavorbender.com/ramen-eggs-ajitsuke-tamago/
https://www.japandigest.de/japan-in-deutschland/rezepte/tokyo-shoyu-ramen/


### Komplettes Gericht

https://www.japandigest.de/japan-in-deutschland/rezepte/omuraisu/ (Ganz lecker)
https://www.japandigest.de/japan-in-deutschland/rezepte/mapo-tofu/ + Brokkoli
https://www.japandigest.de/japan-in-deutschland/rezepte/janina-uhse-okonomiyaki/

### Beilagen

https://www.japandigest.de/japan-in-deutschland/rezepte/brokkoli-salat-mit-tomaten/ (ohne Katsuobushi)

## Muss nicht sein

