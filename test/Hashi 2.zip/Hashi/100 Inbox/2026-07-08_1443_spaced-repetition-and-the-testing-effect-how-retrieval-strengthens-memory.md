---
tomo:
  doc_type: rendered-note
  state: pending-move
  run_id: 2026-07-08T14-43-30Z-7065d3
  updated_at: 2026-07-08T14:43:52Z
UUID: 20260708164501
DateStamp: 2026-07-08
Updated: 2026-07-08 16:45
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Spaced Repetition and the Testing Effect — How Retrieval Strengthens Memory
tags:
  - type/note/normal
  - status/fleeting/🎗️
  - topic/mind
  - topic/knowledge/lyt
aliases:
  - 08.07.2026_1443_Verteilter Wiederholungsrhythmus und der Test-Effekt – Wie das Abrufen das Gedächtnis stärkt
---

> [!connect] Your way around
> up:: 
> related:: 

# [[Spaced Repetition and the Testing Effect — How Retrieval Strengthens Memory]]

``` dataviewjs
let page = dv.current();
if (page.summary && page.summary.length > 0) {
    dv.paragraph("\n**Summary:** _" + page.summary + "_");
}
```

Captured from a talk: spaced repetition works because retrieval effort
strengthens memory (the testing effect). Worth turning into a proper note.

#captures
