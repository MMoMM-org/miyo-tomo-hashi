---
Updated: 2026-07-07 18:03
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:03:08Z
---
Am 2026-07-04 mittags lange mit Anna telefoniert. Sie ueberlegt nach Berlin
zu ziehen wegen des neuen Jobs, ist aber noch unentschlossen. Will bis Ende
des Monats entscheiden. Ich soll ihr die Wohnungslinks schicken.
