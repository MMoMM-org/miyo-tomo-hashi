---
UUID: 20220801142715
DateStamp: 2022-08-01
Updated: 2026-07-07 18:02
publish: false
language: de
Vault: Privat
Year: 2022
tags:
  - "#type/note/zettel"
  - "#status/fleeting/💯"
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:54Z
---
> [!METADATA]-
> - Created:: [[2022-08-01]]
> - Related::
> - Summary::
> - Type:: #type/note/zettel
> - Status:: #status/fleeting/💯

----
# [Fleeting Notes](https://fleetingnotes.app/posts/how-to-build-connections-in-obsidian/)

## How to Build Connections in Obsidian (1 MINUTE)

Last updated July 29, 2022

So you’ve built a [fantastic note-taking workflow](https://fleetingnotes.app/posts/simplest-obsidian-workflow-in-1-minute) but now you have some questions about connections like:

-   Why do I want to connect notes?
-   When do I create links or notes?
-   How do I title notes?

In the next minute, I’ll answer all of these questions and provide a process for creating and connecting notes. This workflow is heavily inspired by the [Zettelkasten](https://fleetingnotes.app/notes/Zettelkasten) method.

## Why do I want to [connect notes](https://fleetingnotes.app/notes/connecting-ideas-is-powerful)?

-   It allows us to:
    -   Reuse notes in different context
    -   Resurface past content which reinforces learning
-   To get the most out of these connections, you’ll need to create [atomic](https://fleetingnotes.app/notes/atomic-things-are-self-contained) notes. In other words, notes that are short and specific to a topic.

## Steps for building connections:

1.  As you write, when specific concepts stand out to you, create a connection for it.
    1.  A good rule to follow is if you think you’ll need it in the future, then create the note.
2.  Once you’ve identified you want to create that link, first search past links you’ve created and check if you’ve already created the link.
3.  If no links exist, create that link. Then populate the link with details of the concept and create a descriptive and concise title. We want to avoid generic titles like `school` or `work`.

---

### Interactive Graph