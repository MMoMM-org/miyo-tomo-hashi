---
Updated: 2026-07-07 18:03
tags:
  - "#captures"
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:03:02Z
---
Captured from a talk: spaced repetition works because retrieval effort
strengthens memory (the testing effect). Worth turning into a proper note.

#captures
