---
Updated: 2026-07-07 18:03
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:03:07Z
---
Spaced repetition schedules reviews of material at expanding intervals — a day, then three days, then a week, then a month. It exploits the spacing effect: memories consolidate better when retrieval is spread out rather than crammed. Each successful recall strengthens the trace and pushes the next review further out; a lapse pulls it back in. Tools like Anki automate the scheduling, but the mechanism is what matters — effortful retrieval just before you would have forgotten is where the learning happens.
