---
tomo:
  doc_type: rendered-note
  state: pending-move
  run_id: 2026-07-08T14-43-30Z-7065d3
  updated_at: 2026-07-08T14:43:52Z
UUID: 20260708164451
DateStamp: 2026-07-08
Updated: 2026-07-08 16:44
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: First-Principles Thinking
tags:
  - type/note/normal
  - status/fleeting/🎗️
  - topic/mind/concepts
  - topic/knowledge/frameworks
aliases:
  - 08.07.2026_1443_Denken nach den Grundprinzipien
---

> [!connect] Your way around
> up:: [[Concepts (MOC)]]
> related:: 

# [[First-Principles Thinking]]

``` dataviewjs
let page = dv.current();
if (page.summary && page.summary.length > 0) {
    dv.paragraph("\n**Summary:** _" + page.summary + "_");
}
```

First principles thinking means breaking a problem down to its most
fundamental truths and reasoning up from there, instead of arguing by
analogy. Aristotle called it the first basis from which a thing is known.
Musk uses it in engineering: what do the laws of physics actually require?
It is slow and effortful, which is why most people reason by analogy —
but it is where genuinely novel solutions come from.
