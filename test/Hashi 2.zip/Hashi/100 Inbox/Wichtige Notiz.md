---
UUID: 20260415131548
DateStamp: 2026-04-15
Updated: 2026-07-07 18:02
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
tags:
  - "#type/note/zettel"
  - "#status/fleeting/💯"
obsidianUIMode: source
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:56Z
---

am 30.03. um 10:00 beim Arzt angerufen, er meinte die Probleme die ich mit meinem Bein habe sollte durch Manuelle Therapie weg gehen, ich sollte mir ein Rezept holen.
