---
UUID: 20260429063012
DateStamp: 2026-04-29
Updated: 2026-07-07 18:02
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
tags:
  - "#type/note/zettel"
  - "#status/fleeting/💯"
obsidianUIMode: source
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:56Z
---


Morgen-Routine heute durchgezogen, ganz am Anfang des Tages 