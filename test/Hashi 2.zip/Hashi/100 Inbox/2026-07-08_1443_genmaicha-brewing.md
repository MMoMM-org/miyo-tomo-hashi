---
tomo:
  doc_type: rendered-note
  state: pending-move
  run_id: 2026-07-08T14-43-30Z-7065d3
  updated_at: 2026-07-08T14:43:52Z
UUID: 20260708164511
DateStamp: 2026-07-08
Updated: 2026-07-08 16:45
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Genmaicha Brewing
tags:
  - type/note/normal
  - status/fleeting/🎗️
  - topic/recreation
aliases:
  - 08.07.2026_1443_Genmaicha-Zubereitung
---

> [!connect] Your way around
> up:: 
> related:: 

# [[Genmaicha Brewing]]

``` dataviewjs
let page = dv.current();
if (page.summary && page.summary.length > 0) {
    dv.paragraph("\n**Summary:** _" + page.summary + "_");
}
```

the genmaicha is better with slightly cooler water than i thought
