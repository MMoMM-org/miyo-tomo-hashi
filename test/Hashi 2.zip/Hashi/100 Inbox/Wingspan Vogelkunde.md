---
UUID: 20260417160002
DateStamp: 2026-04-17
Updated: 2026-07-07 18:03
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
tags:
  - "#type/note/zettel"
  - "#status/fleeting/💯"
obsidianUIMode: source
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:56Z
---

Wingspan verbindet Engine Building mit echten ornithologischen Fakten. Jede Vogelkarte basiert auf realen Arten — Spannweite, Habitat, Nahrung sind wissenschaftlich korrekt.

Die Ozeanien-Erweiterung bringt Nektarressourcen und australische/neuseeländische Vögel. Die Asien-Erweiterung fügt einen Duell-Modus hinzu. Das Spiel gewann 2019 den Kennerspiel des Jahres Preis.
