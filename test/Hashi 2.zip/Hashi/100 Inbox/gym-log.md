---
Updated: 2026-07-07 18:03
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:03:02Z
---
2026-07-06: Krafttraining, 45 Minuten. Kniebeugen, Bankdruecken, Rudern. Danach 10 Minuten Stretching. Energielevel danach deutlich hoeher.
