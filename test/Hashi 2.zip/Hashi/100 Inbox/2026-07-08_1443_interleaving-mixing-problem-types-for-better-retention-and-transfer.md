---
tomo:
  doc_type: rendered-note
  state: pending-move
  run_id: 2026-07-08T14-43-30Z-7065d3
  updated_at: 2026-07-08T14:43:52Z
UUID: 20260708164456
DateStamp: 2026-07-08
Updated: 2026-07-08 16:44
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Interleaving — Mixing Problem Types for Better Retention and Transfer
tags:
  - type/note/normal
  - status/fleeting/🎗️
  - topic/learning
aliases:
  - 08.07.2026_1443_Interleaving- und Mixing-Aufgabentypen für besseres Behalten und Übertragen
---

> [!connect] Your way around
> up:: 
> related:: 

# [[Interleaving — Mixing Problem Types for Better Retention and Transfer]]

``` dataviewjs
let page = dv.current();
if (page.summary && page.summary.length > 0) {
    dv.paragraph("\n**Summary:** _" + page.summary + "_");
}
```

Interleaving mixes different problem types or skills within a single practice session instead of blocking them (all of A, then all of B). It feels harder and slower in the moment, and learners consistently rate it as less effective — yet it produces markedly better retention and transfer. The reason is that interleaving forces you to repeatedly retrieve and choose the right strategy, which is exactly the discrimination you need when the skill is used for real.
