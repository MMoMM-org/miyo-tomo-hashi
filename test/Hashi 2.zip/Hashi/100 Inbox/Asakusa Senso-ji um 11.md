---
UUID: 20260429110114
DateStamp: 2026-04-29
Updated: 2026-07-07 18:02
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
tags:
  - "#type/note/zettel"
  - "#status/fleeting/💯"
obsidianUIMode: source
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:54Z
---
# 2026-04-29

Heute um 11:00 in Asakusa: der Senso-ji ist Tokios ältester Tempel, gegründet 645. Die Kaminarimon mit der riesigen roten Laterne ist das Wahrzeichen, dahinter führt die Nakamise-dori voller Souvenirstände bis zum Haupttempel. Eigene atomic note wert, und sollte mit Zeit 11:00 ins Tageslog verlinkt werden.
