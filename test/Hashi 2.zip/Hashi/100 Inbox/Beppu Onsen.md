---
UUID: 20260429110013
DateStamp: 2026-04-29
Updated: 2026-07-07 18:02
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
tags:
  - "#type/note/zettel"
  - "#status/fleeting/💯"
obsidianUIMode: source
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:54Z
---


Beppu auf Kyushu ist Japans berühmteste Onsen-Stadt — acht große Quellengebiete, die "Hells of Beppu" sind die touristische Attraktion. Die Quelle Umi Jigoku ist kobaltblau durch gelöstes Eisen(II)-sulfat. Heute lange darüber gelesen — passt zur Hokkaido/Japan-Sammlung.
