---
Updated: 2026-07-07 18:03
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:03:02Z
---
Interleaving mixes different problem types or skills within a single practice session instead of blocking them (all of A, then all of B). It feels harder and slower in the moment, and learners consistently rate it as less effective — yet it produces markedly better retention and transfer. The reason is that interleaving forces you to repeatedly retrieve and choose the right strategy, which is exactly the discrimination you need when the skill is used for real.
