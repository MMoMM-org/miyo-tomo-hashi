---
UUID: 20260417150002
DateStamp: 2026-04-17
Updated: 2026-07-07 18:02
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
tags:
  - "#type/note/zettel"
  - "#status/fleeting/💯"
obsidianUIMode: source
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:56Z
---

Hakodate liegt an der Südspitze Hokkaidos und war einer der ersten Häfen, die sich 1854 dem internationalen Handel öffneten. Die Nachtaussicht vom Berg Hakodate gilt als eine der drei schönsten Japans.

Der Morgenmarkt (Asaichi) direkt am Bahnhof bietet frischen Fisch und Meeresfrüchte. Das Motomachi-Viertel zeigt westlichen Architektur-Einfluss aus der Meiji-Zeit. Seit 2016 ist Hakodate per Shinkansen erreichbar.
