---
tomo:
  doc_type: rendered-note
  state: pending-move
  run_id: 2026-07-08T14-43-30Z-7065d3
  updated_at: 2026-07-08T14:43:52Z
UUID: 20260708164506
DateStamp: 2026-07-08
Updated: 2026-07-08 16:45
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Spaced Repetition — Effortful Retrieval as the Engine of Memory
tags:
  - type/note/normal
  - status/fleeting/🎗️
  - topic/knowledge/frameworks
aliases:
  - 08.07.2026_1443_Spaced-Repetition-und-anstrengendes-Abrufen-als-Motor-des-Gedächtnisses
---

> [!connect] Your way around
> up:: 
> related:: 

# [[Spaced Repetition — Effortful Retrieval as the Engine of Memory]]

``` dataviewjs
let page = dv.current();
if (page.summary && page.summary.length > 0) {
    dv.paragraph("\n**Summary:** _" + page.summary + "_");
}
```

Spaced repetition schedules reviews of material at expanding intervals — a day, then three days, then a week, then a month. It exploits the spacing effect: memories consolidate better when retrieval is spread out rather than crammed. Each successful recall strengthens the trace and pushes the next review further out; a lapse pulls it back in. Tools like Anki automate the scheduling, but the mechanism is what matters — effortful retrieval just before you would have forgotten is where the learning happens.
