---
UUID: 20260417150001
DateStamp: 2026-04-17
Updated: 2026-07-07 18:02
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
tags:
  - "#type/note/zettel"
  - "#status/fleeting/💯"
obsidianUIMode: source
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:56Z
---

Sapporo ist die Hauptstadt der Präfektur Hokkaido und mit knapp 2 Millionen Einwohnern die fünftgrößte Stadt Japans. Bekannt für das jährliche Schneefestival (Yuki Matsuri) im Februar, die Bierbrauerei-Tradition und als Austragungsort der Olympischen Winterspiele 1972.

Die Stadt bietet eine Mischung aus urbanem Leben und Naturzugang — der Odori Park teilt das Zentrum, und innerhalb von 30 Minuten erreicht man Skigebiete. Die Ramen-Szene (Miso-Ramen) ist legendär.
