---
Updated: 2026-07-07 18:02
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:54Z
---
source: Apothekerpfädchen 11__2026-04-20 11:48:29.m4a
transcribed: 2026-05-26T15:17:43
recorded: 2026-04-20T11:48:29
model: faster-whisper-medium
language: de
duration_sec: 4
transcribe_sec: 3.43

---

![[Apothekerpfädchen 11__2026-04-20 11:48:29.m4a]]

> [!voice] [[Apothekerpfädchen 11__2026-04-20 11:48:29.m4a#t=0|00:00]]
> Das ist ein Test und ich will mal gucken was hier passiert.

