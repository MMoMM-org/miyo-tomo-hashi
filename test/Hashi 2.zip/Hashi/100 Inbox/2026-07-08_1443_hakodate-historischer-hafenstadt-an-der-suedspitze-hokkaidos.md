---
tomo:
  doc_type: rendered-note
  state: pending-move
  run_id: 2026-07-08T14-43-30Z-7065d3
  updated_at: 2026-07-08T14:43:46Z
UUID: 20260708164431
DateStamp: 2026-07-08
Updated: 2026-07-08 16:44
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Hakodate — Historischer Hafenstadt an der Südspitze Hokkaidos
tags:
  - type/note/normal
  - status/fleeting/🎗️
  - topic/japan
  - topic/japan/city
  - topic/geography
aliases:
  - 2026-07-08_1443_Hakodate-historic-port-city-on-the-southern-tip-of-Hokkaido
---

> [!connect] Your way around
> up:: [[Japan (MOC)]]
> related:: 

# [[Hakodate — Historischer Hafenstadt an der Südspitze Hokkaidos]]

``` dataviewjs
let page = dv.current();
if (page.summary && page.summary.length > 0) {
    dv.paragraph("\n**Summary:** _" + page.summary + "_");
}
```

Hakodate liegt an der Südspitze Hokkaidos und war einer der ersten Häfen, die sich 1854 dem internationalen Handel öffneten. Die Nachtaussicht vom Berg Hakodate gilt als eine der drei schönsten Japans.

Der Morgenmarkt (Asaichi) direkt am Bahnhof bietet frischen Fisch und Meeresfrüchte. Das Motomachi-Viertel zeigt westlichen Architektur-Einfluss aus der Meiji-Zeit. Seit 2016 ist Hakodate per Shinkansen erreichbar.
