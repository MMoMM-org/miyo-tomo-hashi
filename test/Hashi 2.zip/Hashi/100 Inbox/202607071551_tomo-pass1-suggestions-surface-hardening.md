---
title: Tomo Pass-1 suggestions surface hardening
tags:
  - MiYo/Tsukai/Tomo
category: fix
created: 2026-07-07
Summary: Three changes hardening the Tomo Pass-1 suggestions review surface — redundant Skip boxes removed, an analyst content-preview added, and a stale tag-handler group leak closed.
Updated: 2026-07-07 15:52
---

# Tomo Pass-1 suggestions surface hardening

Session working the `_suggestions` review surface (the doc + ADR-026 wire that the Hashi editor consumes). Three related changes landed, each on its own branch, all synced live to the instance.

## What was done

1. **Redundant `Skip` box removed from every decision block** (`fix/decision-blocks-drop-redundant-skip`, PR #130). The tag-handler, per-source `link_to_moc`/`create_moc`/`modify_note`/`update_daily` blocks, and the aggregated `## Proposed MOCs` render all carried a decorative `- [ ] Skip` next to Approve. Extended the already-decided spec-027/ADR-4 rule ("Skip is redundant — un-approving IS skipping") that had only ever been applied to the atomic block.

2. **Analyst 1-sentence `summary` as content preview** (`feat/suggestions-content-summary`). Sub-worthy "kept in inbox" concept notes showed only Source + name + worthiness, so you couldn't tell what a note was about without opening it. The `inbox-analyst` now emits an optional display-only gist per atomic thread; it flows analyst → item-result → reducer (`**Summary:**`) → wire, so Hashi gets it too.

3. **Stale tag-handler group leak closed** (`fix/tag-handler-stale-groups`). A 6-day-old group referencing a since-consumed inbox source reappeared in a fresh run and rendered a live Approve box.

## Why / the underlying insight

The stale-group bug is the notable one: `tomo-tmp/tag-handler-groups/` is **per-run staging that carries no `run_id`** — unlike `items/`, which the reducer filters by run_id (#116). Nothing scoped it to the current run: `reset-tomo-tmp` never cleared it, the LLM interpreter step is gated (skipped when no inbox note is tag-handler-tagged, so it never overwrites the dir), and `tag-handler-writer` never clears. The existing group guard only checks the *target* note, so a stale group with a still-present target passed it. **Latent stale-state class: any per-run staging dir without a run_id filter or a start-of-run clear can leak.**

## Consequence

Two-layer fix: (A) `reset-tomo-tmp --pass1` now clears the staging dir + stubs; (B) the reducer drops any group whose sources are all missing (fail-open, logged). Verified end-to-end via a rich 34-note live fixture: proposed MOCs, existing + non-existing daily updates, log links, MOC placement anchors all render correctly; 2069 tests green.

## Follow-ups

- Open PRs for changes 2 + 3 (stacked on #130); land all three.
- Fresh Pass-1 run to regenerate the vault fixture (clears the stale group + surfaces the new summaries) before handing the example to Hashi.
- Verify live that the analyst emits genuinely useful 1-sentence gists (unit tests cover render/wire/schema only).
- Consider auditing other per-run staging dirs for the same no-run_id stale-state class.
