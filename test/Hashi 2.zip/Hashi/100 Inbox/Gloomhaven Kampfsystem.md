---
UUID: 20260417160003
DateStamp: 2026-04-17
Updated: 2026-07-07 18:02
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
tags:
  - "#type/note/zettel"
  - "#status/fleeting/💯"
obsidianUIMode: source
tomo:
  doc_type: source
  state: captured
  run_id: 2026-07-07T15-25-12Z-d54055
  updated_at: 2026-07-07T16:02:56Z
---

Gloomhavens Kampfsystem basiert auf Kartenmanagement statt Würfeln. Jede Runde wählt man zwei Karten — obere Hälfte einer, untere der anderen. Timing und Handmanagement entscheiden über Sieg oder Niederlage.

Die Erschöpfungsmechanik (Karten gehen permanent verloren) erzeugt natürlichen Zeitdruck. Frosthaven erweitert das System um saisonale Events und Outpost-Management.
