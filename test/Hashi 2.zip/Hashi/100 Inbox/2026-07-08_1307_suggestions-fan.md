---
type: tomo-suggestions
generated: 2026-07-08T13:09:54Z
tomo_version: 0.1.0
profile: miyo
source_items: 15
run_id: 2026-07-08T13-07-06Z-755c28
tomo:
  doc_type: suggestions-fan
  state: approved
  run_id: 2026-07-08T13-07-06Z-755c28
  updated_at: 2026-07-08T14:45:20.636876+00:00
Updated: 2026-07-08 16:45
---

# Inbox Suggestions — 2026-07-08T13-07-06Z-755c28

- [x] Approved

_Edited in Hashi — the sibling `.json` is authoritative; run `/inbox` for Pass 2 to apply these edits._

## Summary

- Suggestions: 15 (15 approve / 0 skip)
- Proposed MOCs: 4 (0 approve / 4 skip)
- Daily updates: 0 date(s), 0 log entries
- Tag-handler groups: 0 (0 approved)

## Suggestions

- S01 · Asahikawa · approve · MOCs: Atlas/200 Maps/Japan (MOC).md, Atlas/200 Maps/Vacation (MOC).md
- S02 · Beppu  · approve · MOCs: (none selected)
- S03 · Catan · approve · MOCs: (none selected)
- S04 · Evergreen Notes · approve · MOCs: Atlas/200 Maps/Type of Notes (MOC).md, Atlas/200 Maps/Linking Your Thinking (MOC).md
- S05 · Furano — Lavendelfelder und Hügellandschaften · approve · MOCs: Atlas/200 Maps/Japan (MOC).md, Atlas/200 Maps/Vacation (MOC).md
- S06 · Gloomhaven · approve · MOCs: (none selected)
- S07 · Hakodate — Historischer Hafenstadt an der Südspitze Hokkaidos · approve · MOCs: Atlas/200 Maps/Japan (MOC).md, Atlas/200 Maps/Vacation (MOC).md
- S08 · Sapporo — Hokkaidos Hauptstadt · approve · MOCs: (none selected)
- S09 · Wingspan · approve · MOCs: (none selected)
- S10 · Deliberate Practice — Focused Effort Beyond Automaticity · approve · MOCs: Atlas/200 Maps/Concepts (MOC).md
- S11 · First-Principles Thinking · approve · MOCs: Atlas/200 Maps/Concepts (MOC).md
- S12 · Interleaving — Mixing Problem Types for Better Retention and Transfer · approve · MOCs: (none selected)
- S13 · Spaced Repetition and the Testing Effect — How Retrieval Strengthens Memory · approve · MOCs: (none selected)
- S14 · Spaced Repetition — Effortful Retrieval as the Engine of Memory · approve · MOCs: (none selected)
- S15 · Genmaicha Brewing · approve · MOCs: (none selected)

## Proposed MOCs

- M01 · Places (MOC) · skip
- M02 · Games (MOC) · skip
- M04 · Knowledge and Memory (MOC) · skip
- M05 · Cooking (MOC) · skip

## Daily Updates

(none)

## Tag-Handler Groups

(none)
