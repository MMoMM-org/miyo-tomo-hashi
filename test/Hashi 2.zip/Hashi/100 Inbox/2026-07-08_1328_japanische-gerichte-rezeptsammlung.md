---
tomo:
  doc_type: rendered-note
  state: pending-move
  run_id: 2026-07-08T13-27-15Z-64bd31
  updated_at: 2026-07-08T13:28:04Z
UUID: 20260708152832
DateStamp: 2026-07-08
Updated: 2026-07-08 15:28
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Japanische Gerichte — Rezeptsammlung
tags:
  - type/note/normal
  - status/fleeting/🎗️
  - topic/japan
aliases:
  - 2026-07-08_1328_Japanese-Dishes-Recipe-Collection
---

> [!connect] Your way around
> up:: [[Japan (MOC)]]
> related:: 

# [[Japanische Gerichte — Rezeptsammlung]]

``` dataviewjs
let page = dv.current();
if (page.summary && page.summary.length > 0) {
    dv.paragraph("\n**Summary:** _" + page.summary + "_");
}
```

> [!METADATA]-
> - Created:: [[2022-12-01]]
> - Related::
> - Summary::
> - Content:: [[Rezept]]
> - up:: 
> - Topics:: 
> - Type:: #type/note/normal
> - Status:: #status/fleeting/🎗️ 
> - **Reference**::
---

# [[Japanische Gerichte]]

## Zum Probieren

### Nudeln

https://www.japandigest.de/japan-in-deutschland/rezepte/spatzlepfanne-nach-yaki-udon-art/
https://www.japandigest.de/japan-in-deutschland/rezepte/yakisoba-mit-spiegelei/
https://www.justonecookbook.com/toshikoshi-soba/

### Komplettes Gericht
https://www.japandigest.de/japan-in-deutschland/rezepte/gyu-don/
https://www.japandigest.de/japan-in-deutschland/rezepte/bauernsuppe-mit-suesskartoffeln/
https://www.japandigest.de/japan-in-deutschland/rezepte/haehnchen-miso-sahne-gemuese/


### Sandwiches
https://www.japandigest.de/japan-in-deutschland/rezepte/patapata-onigirazu/
https://www.japandigest.de/japan-in-deutschland/rezepte/katsu-sando/
https://www.japandigest.de/japan-in-deutschland/rezepte/onigirazu-2/
https://www.japandigest.de/japan-in-deutschland/rezepte/onigirazu/


### Fleisch
https://www.japandigest.de/japan-in-deutschland/rezepte/haehnchenbrust-age-yaki/
https://www.japandigest.de/japan-in-deutschland/rezepte/rindersteak-mit-wasabi/
https://www.japandigest.de/japan-in-deutschland/rezepte/tonkatsu-miso-sauce/
https://www.japandigest.de/japan-in-deutschland/rezepte/buta-no-shogayaki-mit-kohl/


### Sushi

https://www.japandigest.de/japan-in-deutschland/rezepte/futo-maki/

### Beilagen
https://www.japandigest.de/japan-in-deutschland/rezepte/imo-mochi/ (Kartoffeln)
https://www.japandigest.de/japan-in-deutschland/rezepte/gemuese-kimpira/


## Für gut befunden

### Ramen
https://www.theflavorbender.com/easy-homemade-chicken-ramen/ (ohne Dashi)
https://www.theflavorbender.com/ramen-eggs-ajitsuke-tamago/
https://www.japandigest.de/japan-in-deutschland/rezepte/tokyo-shoyu-ramen/


### Komplettes Gericht

https://www.japandigest.de/japan-in-deutschland/rezepte/omuraisu/ (Ganz lecker)
https://www.japandigest.de/japan-in-deutschland/rezepte/mapo-tofu/ + Brokkoli
https://www.japandigest.de/japan-in-deutschland/rezepte/janina-uhse-okonomiyaki/

### Beilagen

https://www.japandigest.de/japan-in-deutschland/rezepte/brokkoli-salat-mit-tomaten/ (ohne Katsuobushi)

## Muss nicht sein
