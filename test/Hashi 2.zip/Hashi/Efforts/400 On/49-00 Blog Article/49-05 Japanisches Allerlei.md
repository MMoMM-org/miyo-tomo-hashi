---
UUID: 20260601120000
DateStamp: 2026-06-01
Updated: 2026-06-01 12:00
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary: Blog-Artikel-Entwurf rund um japanische Themen — Reisen, Essen und Kultur.
title: 49-05 Japanisches Allerlei
tags:
  - type/note/effort
  - topic/japan
aliases:
---

# Japanisches Allerlei

Ein loser Blog-Artikel-Entwurf, der japanische Themen sammelt — Orte, Essen und Kultur.

## Notes

- Erste Ideen und Fragmente hier sammeln.
