---
UUID: 20260422100004
DateStamp: 2026-04-22
Updated: 2026-04-22 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
Summary:
title: 2700 - Art & Recreation
tags:
  - type/others/moc
  - topic/recreation
aliases:
---

> [!connect] Your way around
> up:: 
> related:: 


# [[2700 - Art & Recreation]]

> [!anchor] Overview
> Top-level MOC for art, recreation, board games, sports, and leisure activities.

> [!blocks] Key Concepts
> Core domains under Art & Recreation.

> [!video] Action Items
> Tasks, questions, or areas for further exploration.

> [!compass] Something you should look at perhaps..
