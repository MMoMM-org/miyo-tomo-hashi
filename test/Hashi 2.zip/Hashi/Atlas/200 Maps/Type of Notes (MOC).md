---
UUID: 20260422100002
DateStamp: 2026-04-22
Updated: 2026-04-22 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Type of Notes (MOC)
tags:
  - type/others/moc
  - topic/knowledge/notes
aliases:
---

> [!connect] Your way around
> up:: 
> related:: 

# [[Type of Notes (MOC)]]

> [!anchor] Overview
> Map of note types — fleeting, atomic, evergreen, MOCs, etc.

> [!blocks] Key Concepts
> Core ideas and fundamental principles for note typing.

## Types

- Fleeting notes — quick, disposable captures.
- Atomic notes — one idea per note.
- Evergreen notes — refined and continuously linked.
- Maps of Content — structural index notes.

> [!video] Action Items
> Tasks, questions, or areas for further exploration.

> [!compass] Something you should look at perhaps..
