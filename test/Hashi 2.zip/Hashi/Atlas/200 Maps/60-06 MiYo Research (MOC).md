---
UUID: 20260606100011
DateStamp: 2026-06-06
Updated: 2026-06-06 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
Summary: Research notes on the MiYo project — architecture, cost/context observations, and design decisions.
title: 60-06 MiYo Research (MOC)
tags:
  - type/others/moc
  - topic/knowledge/miyo
aliases:
---

> [!connect] Your way around
> up:: 
> related:: 


# [[60-06 MiYo Research (MOC)]]

> [!anchor] Overview
> Working notes and research on the MiYo ecosystem — Tomo, Kado, Hashi, and the broader design.

> [!blocks] Key Concepts
> Cost and context reduction, local-first design, proposal-first workflows.

## PKM with AI System

Notes on running a PKM with an AI assistant in the loop.

## Claude Code and Memory

How Tomo (Claude Code) manages context and memory.

## Processes

The MOC Squeeze Point and other recurring processes.

> [!video] Action Items
> Tasks, questions, or areas for further exploration.

> [!compass] Something you should look at perhaps..
