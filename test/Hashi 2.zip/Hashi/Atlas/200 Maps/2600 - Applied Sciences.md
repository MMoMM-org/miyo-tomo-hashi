---
UUID: 20260527100002
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
Summary: The place for everything related to Applied Sciences — technology, engineering, and AI.
title: 2600 - Applied Sciences
tags:
  - type/others/moc
  - topic/applied
aliases:
---

> [!connect] Your way around
> up::
> related::

# [[2600 - Applied Sciences]]

---

> [!NOTE]+ 2600 - Applied Sciences
> Applied and practical fields — technology, engineering, computing, and AI.
>
> - Tag: `#topic/applied`

---

> [!compass] Something you should look at perhaps..

> [!boxes]- Unrequited Notes
> Notes which link to this note and are not mentioned in here.
