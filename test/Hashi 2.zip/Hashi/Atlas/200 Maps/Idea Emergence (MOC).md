---
UUID: 20260527100004
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
Summary: It's not just about connecting dots; it's about creating a whole new picture.
title: Idea Emergence (MOC)
tags:
  - type/others/moc
  - topic/knowledge/lyt
aliases:
---

> [!connect] Your way around
> up:: [[Linking Your Thinking (MOC)]]
> related::

# [[Idea Emergence (MOC)]]

> [!anchor] Overview
> Idea Emergence describes the concept that when you have several things, you discover there is more — and while looking further you manifest the thing which is more.

> [!blocks] Key Concepts
> Emergence levels, convergence, divergence, progressive ideation.
> - [[Convergence]]
> - [[Divergence]]

## 4 Patterns of Idea Emergence

- [[Convergence]]
- [[Divergence]]
- [[Progressive Ideation]]
- [[Thought Collisions]]

> [!video] Action Items
> Tasks, questions, or areas for further exploration.

> [!compass] Something you should look at perhaps..
