---
UUID: 20260527100003
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Systems (MOC)
tags:
  - type/others/moc
  - topic/natural/systems
aliases:
---

> [!connect] Your way around
> up::
> related::

# [[Systems (MOC)]]

> [!anchor] Overview
> Systems thinking, emergence, convergence, divergence — how complex wholes arise from parts.

> [!blocks] Key Concepts
> Core ideas about systems and emergence.
- [[Higher Order Notes]]

> [!video] Action Items
> Tasks, questions, or areas for further exploration.

> [!compass] Something you should look at perhaps..
