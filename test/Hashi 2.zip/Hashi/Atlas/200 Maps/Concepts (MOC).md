---
UUID: 20260527100013
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
Summary: A map of mental-model and thinking concepts — first principles, interleaving, deliberate practice.
title: Concepts (MOC)
tags:
  - type/others/moc
  - topic/mind/concepts
aliases:
---

> [!connect] Your way around
> up:: 
> related:: 


# [[Concepts (MOC)]]

> [!anchor] Overview
> Core thinking concepts and mental models.

> [!blocks] Key Concepts
> First principles, interleaving, deliberate practice, retrieval.

> [!video] Action Items
> Tasks, questions, or areas for further exploration.

> [!compass] Something you should look at perhaps..
