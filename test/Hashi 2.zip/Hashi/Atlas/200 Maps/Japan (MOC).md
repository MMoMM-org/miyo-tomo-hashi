---
UUID: 20260422100001
DateStamp: 2026-04-22
Updated: 2026-04-22 10:00
locale: de
Vault: Privat-Test
VaultVersion: 2
Summary:
title: Japan (MOC)
tags:
  - type/others/moc
  - topic/japan
aliases:
---

> [!connect] Your way around
> up:: 
> related:: 


# [[Japan (MOC)]]

> [!anchor] Overview
> Notes on Japan — places, food, culture, language.

> [!blocks] Key Concepts
> Core ideas and fundamental principles related to Japan.

## Notable Cities

- [[Sapporo]]
> [!video] Action Items
> Tasks, questions, or areas for further exploration.

> [!compass] Something you should look at perhaps..
