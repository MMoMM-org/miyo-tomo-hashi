---
UUID: 20260527100010
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
Summary: How I run my personal knowledge management — capture, linking, and the practices that keep it alive.
title: My PKM (MOC)
tags:
  - type/others/moc
  - topic/knowledge/pkm
aliases:
---

> [!connect] Your way around
> up:: [[Linking Your Thinking (MOC)]]
> related::


# [[My PKM (MOC)]]

> [!anchor] Overview
> My personal knowledge management system — how notes are captured, linked, and matured over time.

> [!blocks] Key Concepts
> Capture, atomic notes, linking, and letting structure emerge.

## Best practices

- Capture first, organise later.
- One idea per note; link generously.
- Let structure emerge from links, not folders.

## Managing my PKM system

How I keep the system running — reviews, refactors, and tooling.

## Managing my PKM workflows

The recurring workflows that move notes from inbox to evergreen.

> [!video] Action Items
> Tasks, questions, or areas for further exploration.

> [!compass] Something you should look at perhaps..
