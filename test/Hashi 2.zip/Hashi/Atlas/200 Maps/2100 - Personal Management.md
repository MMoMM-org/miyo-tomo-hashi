---
UUID: 20260422100002
DateStamp: 2026-04-22
Updated: 2026-04-22 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
Summary:
title: 2100 - Personal Management
tags:
  - type/others/moc
  - topic/personal-management
aliases:
---

> [!connect] Your way around
> up:: 
> related:: 

# [[2100 - Personal Management]]

> [!anchor] Overview
> Top-level MOC for personal management — habits, health, fitness, productivity, daily routines.

> [!blocks] Key Concepts
> Core domains under Personal Management.

> [!video] Action Items
> Tasks, questions, or areas for further exploration.

> [!compass] Something you should look at perhaps..
