---
UUID: 20260527100012
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
Summary: Notes on building and sustaining habits — routines, cues, and deliberate practice.
title: Habits (MOC)
tags:
  - type/others/moc
  - topic/personal/habits
aliases:
---

> [!connect] Your way around
> up:: 
> related:: 


# [[Habits (MOC)]]

> [!anchor] Overview
> Habit formation and maintenance — routines, cues, streaks, and deliberate practice.

> [!blocks] Key Concepts
> Cue-routine-reward loops, consistency over intensity, deliberate practice.

> [!video] Action Items
> Tasks, questions, or areas for further exploration.

> [!compass] Something you should look at perhaps..
