---
UUID: 20260527100020
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
Summary: Trips, destinations, and things to do — travel planning and holiday notes.
title: Vacation (MOC)
tags:
  - type/others/moc
  - topic/recreation/travel
aliases:
---

> [!connect] Your way around
> up:: 
> related:: 


# [[Vacation (MOC)]]

> [!anchor] Overview
> Travel and holiday planning — destinations, itineraries, food, and things to do.

> [!blocks] Planning
> Trips being planned and ideas to work in.

> [!video] Action Items
> Tasks, questions, or areas for further exploration.

> [!compass] Something you should look at perhaps..
