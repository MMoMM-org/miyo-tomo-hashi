---
UUID: 20260527100016
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Mapmaking
tags:
  - type/note/normal
  - topic/knowledge/lyt
aliases:
Summary: Creating and refining visual frameworks that organize and connect ideas.
---

> [!connect] Your way around
> up:: [[Linking Your Thinking (MOC)]]
> related:: [[Mapping Method]], [[Mapping Method vs Mapmaking]], [[Map]], [[Map of Content]]

# [[Mapmaking]]

Mapmaking in LYT involves creating and refining visual frameworks — such as MOCs — that organize and connect ideas, providing a structured yet dynamic network for navigating and understanding complex knowledge.
