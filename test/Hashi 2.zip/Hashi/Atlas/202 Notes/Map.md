---
UUID: 20260527100017
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Map
tags:
  - type/note/normal
  - topic/knowledge/lyt
aliases:
Summary: Maps free your mind by capturing ideas, clustering them meaningfully, and smashing them together to generate new insights.
---

> [!connect] Your way around
> up:: [[Map of Content]]
> related:: [[Mapping Method]], [[Mapmaking]]

# [[Map]]

Maps free your mind by capturing ideas, clustering them meaningfully, and smashing them together to generate new insights. A map is a dynamic process for exploring and connecting ideas.
