---
UUID: 20260527100021
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Divergence
tags:
  - type/note/normal
  - topic/knowledge/lyt
aliases:
Summary:
---

> [!connect] Your way around
> up:: [[Idea Emergence (MOC)]]
> related:: [[Systems (MOC)]]

# [[Divergence]]

Divergence is the spreading out of ideas — exploring possibilities, generating options, and branching into new territory. It's the creative expansion phase of knowledge work.
