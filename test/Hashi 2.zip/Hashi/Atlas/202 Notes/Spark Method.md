---
UUID: 20260527100025
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Spark Method
tags:
  - type/note/normal
  - topic/knowledge/lyt
  - topic/knowledge/frameworks
aliases:
Summary: The Spark Method involves capturing interesting information, explaining why it sparks interest, and relating it to other knowledge.
---

> [!connect] Your way around
> up:: [[Notemaking]]
> related:: [[The 7 C's of Notemaking]], [[ARC Framework]], [[Mapping Method]], [[Mapping MOCs]]

# [[Spark Method]]

The Spark Method is about capturing what resonates: when something interesting sparks your attention, you don't just note it down — you explain why it sparked, and relate it to what you already know.
