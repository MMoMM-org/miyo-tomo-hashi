---
UUID: 20260527100027
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Higher Order Notes
tags:
  - type/note/normal
  - topic/knowledge/lyt
aliases:
Summary: The entrance to the rabbit hole of Maps and MOCs
---

> [!connect] Your way around
> up:: [[Linking Your Thinking (MOC)]]
> related:: [[Map]], [[Map of Content]], [[Map vs MOC]]

# [[Higher Order Notes]]

Higher Order Notes — like Maps of Content — play a crucial role in facilitating [[Thought Collisions]]. They help create relationships between ideas, bridge gaps, and ground understanding.
