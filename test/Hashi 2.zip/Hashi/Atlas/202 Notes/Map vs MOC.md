---
UUID: 20260527100019
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Map vs MOC
tags:
  - type/note/normal
  - topic/knowledge/lyt
aliases:
Summary: A map is a dynamic process for exploring ideas, while a MOC is a structured note linking related content.
---

> [!connect] Your way around
> up:: [[Map]]
> related:: [[Mapping Method]], [[Map of Content]]

# [[Map vs MOC]]

A map is a dynamic process for exploring and connecting ideas, while a MOC is a structured note linking related content. The distinction matters for understanding how knowledge work flows.
