---
UUID: 20260527100012
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Progressive
tags:
  - type/note/atomic
  - topic/knowledge/lyt
aliases:
Summary: Growing, maturing, evolving, compounding
---

> [!connect] Your way around
> up:: [[Idea Emergence (MOC)]]
> related:: [[Emergent]], [[Output-Driven]], [[Tension-Resolving]]

# [[Progressive]]

[[Progressive Ideation]] is the process of relating and developing ideas over time. It is closely coupled with the [[ARC Framework]].
