---
UUID: 20260527100014
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Notemaking
tags:
  - type/note/normal
  - topic/knowledge/lyt
aliases:
Summary: Don't just collect facts, cultivate connections with notemaking.
---

> [!connect] Your way around
> up:: [[Linking Your Thinking (MOC)]]
> related:: [[Frameworks (MOC)]]

# [[Notemaking]]

Notemaking goes beyond note-taking. Instead of passively recording information, you actively engage with ideas — connecting them, questioning them, and making them your own.
