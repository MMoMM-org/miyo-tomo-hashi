---
UUID: 20260527100011
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: The 7 C's of Notemaking
tags:
  - type/note/normal
  - topic/knowledge/lyt
  - topic/knowledge/frameworks
aliases:
Summary: Promoting clarity, creativity, and organization in Notemaking.
---

> [!connect] Your way around
> up:: [[Notemaking]]
> related:: [[Spark Method]], [[ARC Framework]], [[Mapping Method]], [[Frameworks (MOC)]]

# [[The 7 C's of Notemaking]]

A framework promoting clarity, creativity, and organization in the notemaking process. The 7 C's provide a structured approach to developing and refining notes.
