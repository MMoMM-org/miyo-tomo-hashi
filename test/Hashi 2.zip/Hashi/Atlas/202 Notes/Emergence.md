---
UUID: 20260527100020
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Emergence
tags:
  - type/note/normal
  - topic/knowledge/lyt
aliases:
Summary:
---

> [!connect] Your way around
> up:: [[Idea Emergence (MOC)]]
> related:: [[Systems (MOC)]]

# [[Emergence]]

Emergence is when the new whole is greater than the sum of its parts. In knowledge work, it happens when notes combine to reveal insights none of them held individually.
