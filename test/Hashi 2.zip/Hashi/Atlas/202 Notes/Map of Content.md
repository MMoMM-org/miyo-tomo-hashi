---
UUID: 20260527100018
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Map of Content
tags:
  - type/note/normal
  - topic/knowledge/lyt
aliases:
  - MOC
Summary: MOCs serve as overlays that add structure without limiting access to your notes.
---

> [!connect] Your way around
> up:: [[Linking Your Thinking (MOC)]]
> related:: [[Map vs MOC]] [[Map]]

# [[Map of Content]]

MOCs serve as overlays that add structure without limiting access to your notes, allowing for flexible and heterarchical organization. They become a tightly-packed room where ideas have to jostle for positioning.
