---
UUID: 20260527100015
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Mapping Method vs Mapmaking
tags:
  - type/note/normal
  - topic/knowledge/lyt
aliases:
Summary: The Mapping Method focuses on the creative process, while mapmaking encompasses both process and structured outcomes.
---

> [!connect] Your way around
> up:: [[Map]]
> related:: [[Mapping Method]], [[Mapmaking]]

# [[Mapping Method vs Mapmaking]]

The Mapping Method tends to focus more on the creative process, while mapmaking encompasses both the process and the structured outcomes.
