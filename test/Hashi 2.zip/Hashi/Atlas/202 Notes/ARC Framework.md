---
UUID: 20260527100023
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: ARC Framework
tags:
  - type/note/normal
  - topic/knowledge/lyt
  - topic/knowledge/frameworks
aliases:
Summary:
---

> [!connect] Your way around
> up:: [[Linking Your Thinking (MOC)]]
> related:: [[Frameworks (MOC)]], [[Mapping Method]], [[Spark Method]], [[The 7 C's of Notemaking]]

# [[ARC Framework]]

The ARC Framework — Add, Relate, Communicate — is a cycle for developing ideas. Add new ideas with personal interpretation, relate them to other ideas, and communicate your insights. It evolved from the earlier ACE (Add / Connect / Express) framework.
