---
UUID: 20260527100026
DateStamp: 2026-05-27
Updated: 2026-05-27 10:00
locale: en
Vault: Privat-Test
VaultVersion: 2
title: Mapping Method
tags:
  - type/note/normal
  - topic/knowledge/lyt
  - topic/knowledge/frameworks
aliases:
Summary: A dynamic, iterative process for exploring and connecting ideas.
---

> [!connect] Your way around
> up:: [[Notemaking]]
> related:: [[Spark Method]], [[ARC Framework]], [[The 7 C's of Notemaking]], [[Frameworks (MOC)]], [[Mapping Method vs Mapmaking]]

# [[Mapping Method]]

The Mapping Method is a dynamic, iterative process for exploring and connecting ideas, fostering creativity and insight through cycles of collection, clustering, and collision.
