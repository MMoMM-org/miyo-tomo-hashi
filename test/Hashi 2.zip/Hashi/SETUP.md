# Test Vault — `test/Hashi`

> Local manual-QA vault for the **miyo-tomo-hashi** plugin.
> Everything in this directory is **gitignored** (per repo `.gitignore` line 16).
> Use this vault for the first round of real-Obsidian testing before moving to `../temp/Privat-Test`.

## Layout

```
test/Hashi/
├── .obsidian/                          # Obsidian config (preserved across resets)
│   └── plugins/miyo-tomo-hashi/        # ← plugin gets deployed here
├── 100 Inbox/                          # vault content (Tomo-emitted docs + peers)
│   ├── *_instructions.json / .md       #   instruction sets (2 sets)
│   ├── *_suggestions.md                #   primary suggestions doc
│   ├── *_suggestions-fan.md            #   force-atomic-resolve doc
│   ├── *_moc-proposal-*.md             #   MOC proposal doc
│   ├── *_<slug>.md                     #   rendered note files (ready to move)
│   └── <original inbox notes>.md       #   user-authored inbox items
├── Atlas/                              # MOC + note destinations
│   ├── 200 Maps/                       #   10 MOCs (LYT classification tree)
│   └── 202 Notes/                      #   19 PKM concept notes
├── Calendar/                           # daily-note destinations
│   └── 301 Daily/                      #   6 daily notes
├── Archive.zip                         # ← canonical snapshot for resets
├── 100 Inbox.zip                       # subset of Archive.zip — kept for reference
├── reset-vault.sh                      # restore vault to Archive.zip state
└── SETUP.md                            # this file
```

## Quick start

```bash
# 1. Reset the vault to a known-good state
bash test/Hashi/reset-vault.sh

# 2. Build + deploy the plugin into .obsidian/plugins/miyo-tomo-hashi/
HASHI_DEPLOY_VAULT=1 npm run build

# 3. Open the vault in Obsidian
#    File → Open vault → "Open folder as vault" → /Volumes/Moon/Coding/MiYo/Hashi/test/Hashi

# 4. Enable the plugin
#    Settings → Community plugins → miyo-tomo-hashi → toggle on
#    (If "Restricted mode" is on, turn it off first)

# 5. Configure the plugin
#    Settings → miyo-tomo-hashi
#    - Tomo inbox folder: 100 Inbox
#    - Hooks dir: <leave default or empty>
#    - Hooks policy: disabled  (start safe; flip to ask/enabled later)
#    - Execution mode: confirm  (so you see the modal first)
#    - Run log retention: always (so we can inspect every run)
```

## What's already in the vault

### Inbox documents

The `100 Inbox/` contains real Tomo-emitted documents covering multiple doc types:

| File | Type | Actions / Sections | Tomo version |
|------|------|-------------------|--------------|
| `2026-05-26_1836_suggestions.md` | `tomo-suggestions` | 10 suggestions, 4 proposed MOCs, 5 daily updates | 0.1.0 |
| `2026-05-26_1902_suggestions-fan.md` | `tomo-suggestions` (suggestions-fan) | 3 force-atomic-resolve proposals | 0.1.0 |
| `2026-05-26_1918_instructions.json` + `.md` | `tomo-instructions` | 57 actions: 3 create_moc, 12 move_note, 19 link_to_moc, 6 daily updates, 12 delete_source, 1 skip | 0.9.0 |
| `2026-05-27_0638_moc-proposal-pkm-moc.md` | `tomo-proposal` (moc-proposal) | 5 MOC proposals (3 accepted, 1 skipped, 1 pending) | — |
| `2026-05-27_1253_instructions.json` + `.md` | `tomo-instructions` | 29 actions: 4 create_moc, 24 marker updates (related::/up::), 1 link_to_moc | 0.9.0 |

Plus 15 original user-authored inbox notes and 16 rendered note/MOC files ready to be moved.

### Atlas (pre-populated)

The `Atlas/` folder contains pre-existing notes that the instructions reference as update targets:

- **`200 Maps/`** — 10 MOCs forming the LYT classification tree (2000 Knowledge Management, 2100 Personal Management, 2700 Art & Recreation, 2900 History & Geography, Frameworks, Systems, Idea Emergence, Japan, LYT, Type of Notes)
- **`202 Notes/`** — 19 PKM concept notes (Thought Collisions, ARC Framework, Mapping Method, Notemaking, etc.) with `up::` and `related::` markers that the `2026-05-27` instructions will update

### Calendar

6 daily notes in `Calendar/301 Daily/` for dates referenced by daily-update instructions.

## Tomo doc types covered

This vault exercises five Tomo document types:

| `doc_type` | Frontmatter `type` | Purpose |
|------------|-------------------|---------|
| `suggestions` | `tomo-suggestions` | Primary inbox analysis — per-item decisions, daily updates, proposed MOCs |
| `suggestions-fan` | `tomo-suggestions` | Force-Atomic Resolve — follow-up proposals for items the user force-promoted |
| `moc-proposal` | `tomo-proposal` | Standalone MOC clustering proposals triggered by tag overlap |
| `instructions` | `tomo-instructions` | Executable instruction sets (JSON + peer MD) |

All instruction files use **Format B** peer naming (`_instructions.json` → `_instructions.md`).

## Test plan (recommended order)

Walk the rows in `docs/XDD/specs/002-instruction-executor/plan/manual-qa-checklist.md`. Recommended group order:

1. **Plugin loads at all** — check DevTools console for errors on enable.
2. **Status bar 橋 indicator** — should appear idle.
3. **Settings UI** — open Settings tab; verify controls render and persist values across reload.
4. **Command + file menu** — palette command, right-click on peer `.md`, right-click on `.json` (no entry expected).
5. **Single-file execution — happy path** — open `2026-05-26_1918_instructions.md` peer, run command, watch the modal:
   - Preview shows action rows grouped by source file
   - Execute → progress glyphs animate
   - Summary shows `✓ A · ⊘ S · ✗ F (Xs)`
   - Run log appears in `100 Inbox/` as `tomo-hashi-run-log_YYYY-MM-DDTHHMM.md`
   - JSON `applied: true` flags written for successful actions
   - Peer `.md` checkboxes ticked (best-effort)
   - **Verify**: MOCs created in `Atlas/200 Maps/`, notes moved to `Atlas/202 Notes/`, links added to existing MOCs, daily notes updated, source notes deleted
6. **Second instruction set** — run `2026-05-27_1253_instructions.md`:
   - **Verify**: 4 new MOCs created, `related::` and `up::` markers updated on 19 existing notes, link added to `2000 - Knowledge Management.md`
7. **Partial-resume** — re-run either instructions file. Banner should say "0 of N remaining — all actions already applied". Execute button disabled.
8. **Halt-on-dependency** — manually break a `create_moc` (e.g. set `destination` to an invalid path), re-run after `applied: false` reset. Verify dependent `link_to_moc` actions record as `skipped-dependency`.
9. **Batch invocation** — close the active file, run command from palette → batch picks up all `_instructions.json` in inbox.
10. **Cancellation** — start a run, click Cancel during progress. Remaining actions recorded as `skipped-cancelled`.
11. **Hooks** — flip `hooksPolicy` to `ask`, drop a hook file in `hooksDir`, run again, observe disclosure modal.
12. **Edge cases** — empty inbox, malformed JSON, peer missing, etc.

## New-feature walk (2026-06-13 — SYNTHETIC dummy)

Tests the two new features on PRs **#64** (one-time permanent-delete warning) and
**#65** (`link_to_moc` insert primitive: `placement: "before"` + multi-line
`line_to_add`). The deployed plugin build (`test/combined-insert-trash-walk`)
contains **both**.

> **Synthetic, not Tomo-emitted.** The fixture `100 Inbox/2026-06-13_1200_instructions.json`
> is hand-authored — it smoke-tests Hashi's behaviour, it does **not** close the
> Tomo↔Hashi drift gate. The real walk uses a fresh Tomo emission (handoff filed
> in `_outbox/for-tomo/`); install this Hashi build into the Tomo test vault and
> run a real `link_to_moc` emission there.

**Setup for this walk**

1. `bash test/Hashi/reset-vault.sh` then `HASHI_DEPLOY_VAULT=1 npm run build`
2. Open `test/Hashi` in Obsidian; enable plugin; inbox folder = `100 Inbox`; execution mode = `confirm`.
3. For the delete-warning test: **Settings → Files & Links → Deleted files → "Permanently delete"** (this is the Obsidian app setting — the warning only fires when it's permanent). To test the recoverable path instead, set it to "Move to system trash" or ".trash folder".

**Run** the peer `100 Inbox/2026-06-13_1200_instructions.md` (palette → "Execute instructions document") and verify:

| Action | Target | Expect |
|--------|--------|--------|
| I01 — before + multi-line | `Japan (MOC)` | A new `## Notable Cities` / blank / `- [[Sapporo]]` block lands **directly above** the `> [!video] Action Items` line. No `> ` prefix. |
| I02 — before single-line | `Frameworks (MOC)` | `## See Also` lands directly above the `> [!compass] …` line. No `> ` prefix. |
| I03 — multi-line inside callout | `Idea Emergence (MOC)` | `> - [[Convergence]]` and `> - [[Divergence]]` appended as the last two body lines **inside** the `[!blocks] Key Concepts` callout (each `> `-prefixed). |
| I04 — after (regression) | `Systems (MOC)` | `- [[Higher Order Notes]]` inserted right after the Key Concepts callout closes; no `> ` prefix (unchanged behaviour). |
| I05 — delete_source | `100 Inbox/Test - Delete Me.md` | With "Permanently delete": a **one-time** Notice warns deletion is permanent/non-recoverable, then the file is gone. Re-run (after resetting `applied`) → **no** second Notice. With system/`.trash`: no Notice, file recoverable. |

**Re-run idempotency:** running a second time (without reset) should report every `link_to_moc` as `skipped-already` (the blocks/lines are already present) — no duplicate inserts.

> Note: each `link_to_moc` targets a **different** MOC on purpose — Obsidian's
> metadata cache lags a `vault.process` write, so two inserts into the *same*
> MOC in one run can use stale line numbers. A real Tomo walk rarely stacks
> multiple inserts on one MOC; if it does, that's a finding worth logging.

## Resetting after a destructive test

```bash
bash test/Hashi/reset-vault.sh
HASHI_DEPLOY_VAULT=1 npm run build
```

The script wipes everything except `.obsidian/`, the `.zip` files, the script itself, and this `SETUP.md`. Then it re-extracts `Archive.zip`.

## Capturing observations

For each finding (drift, bug, surprise), do **one** of:

1. If it contradicts the spec → add a row to `docs/XDD/specs/002-instruction-executor/README.md` Decisions Log
2. If it's a minor implementation gap → add to `docs/XDD/specs/002-instruction-executor/plan/README.md` Follow-up tasks
3. If it's just a note → keep it in this file under "Session notes" below

## Session notes

<!-- 2026-04-29 — first manual round in test/Hashi -->
<!-- 2026-05-27 — expanded vault with PKM notes, MOCs, and new Tomo doc types (suggestions, suggestions-fan, moc-proposal) -->
